import AppBar from "./Components/UI/AppBar";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap"
import "./Components/UI/style.css"
import Slider from "./Components/UI/Slider";
import RegistrationForm from "./Components/User/RegistrationFrom";
function App() {
  return (
    <>
      <AppBar></AppBar>
      <Slider/>
      <RegistrationForm></RegistrationForm>
    </>
  );
}

export default App;
