const initialState = {
  email: false,
  mobile: false,
};

const Users = (state = initialState, action) => {
  switch (action.type) {
    case "USERS_EMAIL_FOUND":
      return { ...state, email: true };
    case "USERS_MOBILE_FOUND":
      return { ...state, mobile: true };
    case "USERS_EMAIL_NOT_FOUND":
      return { ...state, email: false };
    case "USERS_MOBILE_NOT_FOUND":
      return { ...state, mobile: false };
    default:
      return state;
  }
};

export default Users;
