import axios from "axios";
import { db } from "../../Firebase";

export const UserAction = (payload) => {
  return (dispatch) => {
    db.collection("App_users")
      .get()
      .then((QureySnapshot) => {
        let data = [];
        QureySnapshot.forEach((e) => {
          data.push(e.data().values);
        });

        let cnt = 0;
        data.forEach((e) => {
          if (e.txtemail === payload) {
            cnt++;
          }
        });
        if (cnt != 0) {
          dispatch({ type: "USERS_EMAIL_FOUND" });
        } else {
          dispatch({ type: "USERS_EMAIL_NOT_FOUND" });
        }
      });
  };
};
