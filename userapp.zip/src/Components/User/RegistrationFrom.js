import React, { useEffect, useRef, useState } from "react";
import TextField from "@mui/material/TextField";
import Jump from "react-reveal/Jump";
import Radio from "@mui/material/Radio";
import RadioGroup from "@mui/material/RadioGroup";
import FormControlLabel from "@mui/material/FormControlLabel";
import FormControl from "@mui/material/FormControl";
import FormLabel from "@mui/material/FormLabel";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import Select from "@mui/material/Select";
import { Formik } from "formik";
import * as Yup from "yup";
import Button from "@mui/material/Button";
import moment from "moment";
import DateAdapter from "@mui/lab/AdapterMoment";
import LocalizationProvider from "@mui/lab/LocalizationProvider";
import DesktopDatePicker from "@mui/lab/DesktopDatePicker";
import MuiPhoneNumber from "material-ui-phone-number";
import axios from "axios";
import Auth, { db } from "../../Firebase";
// import Auth from "../../Firebase";
import { useDispatch } from "react-redux";
import { UserAction } from "../../Storage/Action/UserAction";
import { useSelector } from "react-redux";
import { UserMobileAction } from "../../Storage/Action/UserMobileAction";

const RegistrationForm = () => {
  //!!!!!!!!!!!!!Initialization!!!!!!!!!!!!!!!

  const emailStatus = useSelector((state) => state.email);
  const mobileStatus = useSelector((state) => state.mobile);
  const dispatch = useDispatch();
  const [country, setCountry] = useState([]);
  const [state, setState] = useState([]);
  const [city, setCity] = useState([]);
  const text = useRef();
  const imgName = useRef();
  const [showState, setShowState] = useState(false);
  const [showCity, setShowCity] = useState(false);
  const [imgError, setimgError] = useState(false);
  const [imgErrorMsg, setimgErrorMsg] = useState("");
  const initialValues = {
    txtname: "",
    txtlname: "",
    txtemail: "",
    txtpassword: "",
    txtdate: new Date(),
    txtmobile: "",
    txtrole: "",
    txtprofile: "",
    txtcountry: "",
    txtwebite: "",
    txtstate: "",
    txtcity: "",
    txtzipcode: "",
    txtaddress: "",
  };

  //!!!!!!!!!!!!!Initialization!!!!!!!!!!!!!!!

  //-----------------Functions-----------------

  useEffect(() => {
    axios
      .get("http://localhost:3300/country")
      .then((res) => setCountry(res.data));
  }, []);

  const getState = (e) => {
    const id = e.target.value;
    axios
      .get("http://localhost:3300/state?country_id=" + id)
      .then((res) => setState(res.data));
    setShowState(true);
  };
  const getCity = (e) => {
    const id = e.target.value;
    axios
      .get("http://localhost:3300/city?state_id=" + id)
      .then((res) => setCity(res.data));
    setShowCity(true);
  };

  const getBase64 = (file) => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        resolve(reader.result);
        imgName.current.src = e.target.result;
      };
      reader.onerror = (er) => reject(er);
      reader.readAsDataURL(file);
    });
  };

  //-----------------Functions-----------------

  //-*--*-*-*-*-*-*--*-*-Validation Schema*-*-*-*-*-*-*-*-*-

  const validationSchema = Yup.object({
    txtname: Yup.string()
      .required("Please enter the required field")
      .min(2, "The Name Contains Atleast 2 Charecters")
      .max(15, "The Name Contains Maximum 15 Charecters")
      .matches("^[a-zA-z]+$", "Only alphabets are allowed for this field "),
    txtlname: Yup.string()
      .required("Please enter the required field")
      .min(2, "The Name Contains Atleast 2 Charecters")
      .max(15, "The Name Contains Maximum 15 Charecters")
      .matches("^[a-zA-z]+$", "Only alphabets are allowed for this field "),
    txtemail: Yup.string()
      .email("Please Enter Valid Email!!!")
      .required("Please enter the required field")
      .test("txtemail", "Email Already Exists", (e) => {
        return !emailStatus;
      }),
    txtpassword: Yup.string()
      .required("Please enter the required field")
      .min(8, "Minimum 8 Charecters Are Required!!!")
      .max(25, "Maximum 25 Charecters Are Allowed!!!")
      .matches(
        /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*]).{8,}$/,
        // .matches(
        //   //"^[a-zA-z0-9{2,}]+$",
        //   //"^([a-zA-Z]){2,}([0-9]){2,}+$",
        // "^([a-zA-Z]).{2,}.([0-9]).{2,}.([$&+,:;=?@#|'<>.^*()%!-]).{2,}+$/gm",
        "Password Contains Atleast 2 Alphabates , 2 Digits"
      ),
    txtdate: Yup.date()
      .required("Please enter the required field")
      .max(
        new Date(moment().subtract(18, "years")),
        "You Must Be 18 Years OLD!"
      ),
    txtrole: Yup.string().required("Please enter the required field"),
    txtmobile: Yup.string()
      .test("txtmobile", "Please Enter A Valid Mobile Number!!!!", (v) => {
        if (v) {
          const after = v.slice(v.indexOf(" ") + 1);
          let mobileNumber = after.replace("(", "");
          mobileNumber = mobileNumber.replace(")", "");
          mobileNumber = mobileNumber.replace("-", "");
          mobileNumber = mobileNumber.replace(" ", "");
          return mobileNumber.length === 10;
        }
      })
      .test("txtmobile", "Mobile Already Exists", (e) => {
        return !mobileStatus;
      }),
    txtcountry: Yup.string().required("Please enter the required field"),
    txtstate: Yup.string().required("Please enter the required field"),
    txtcity: Yup.string().required("Please enter the required field"),
    txtzipcode: Yup.string()
      .required("Please enter the required field")
      .min(6, "ZipCode Must Be 6 Digit Only")
      .max(6, "ZipCode Must Be 6 Digit Only"),
    txtaddress: Yup.string()
      .required("Please enter the required field")
      .min(5, "Minimum 5 Charecters Required")
      .max(200, "Maximum 200 Charecters Allowed"),
  });

  //-*--*-*-*-*-*-*--*-*-Validation Schema*-*-*-*-*-*-*-*-*-

  return (
    <div className="RegistraionForm" id="reg_form">
      <div className="container-fluid">
        <div className="row">
          <div className="col-6 offset-1 mt-5">
            <div className="card reg-card border-dark">
              <Formik
                initialValues={initialValues}
                validationSchema={validationSchema}
                onSubmit={(values, { resetForm }) => {
                  Auth.createUserWithEmailAndPassword(
                    values.txtemail,
                    values.txtpassword
                  )
                    .then((success) => {
                      success.user.sendEmailVerification();
                      Auth.signOut();
                      alert("Email successfully sent for Verification!!");
                    })
                    .catch((ex) => {
                      console.log(ex);
                    });
                  db.collection("App_users")
                    .add({
                      values,
                    })
                    .then(() => {
                      alert("User Registerd successfully!!!.");
                    });
                  resetForm();
                  imgName.current.src = "";
                  setShowState(false);
                  setShowCity(false);
                }}
              >
                {({
                  values,
                  errors,
                  touched,
                  handleChange,
                  handleBlur,
                  handleSubmit,
                  setFieldValue,
                  setFieldTouched,
                  isSubmitting,
                  /* and other goodies */
                }) => (
                  <form onSubmit={handleSubmit}>
                    <div className="card-header bg-transparent p-3 border-0">
                      <h3>Register Now</h3>
                    </div>
                    <div className="card-body p-5">
                      <div className="row mb-3">
                        <TextField
                          error={errors.txtname && touched.txtname && true}
                          label="Enter First Name"
                          name="txtname"
                          onChange={handleChange}
                          onBlur={handleBlur}
                          value={values.txtname}
                          variant="outlined"
                        />
                        <div className="error">
                          {errors.txtname && touched.txtname && (
                            <Jump>{errors.txtname}</Jump>
                          )}
                        </div>
                      </div>
                      <div className="row mb-3">
                        <TextField
                          error={errors.txtlname && touched.txtlname && true}
                          label="Enter Last Name"
                          name="txtlname"
                          onChange={handleChange}
                          onBlur={handleBlur}
                          value={values.txtlname}
                          variant="outlined"
                        />
                        <div className="error">
                          {errors.txtlname && touched.txtlname && (
                            <Jump>{errors.txtlname}</Jump>
                          )}
                        </div>
                      </div>
                      <div className="row mb-3">
                        <TextField
                          error={errors.txtemail && touched.txtemail && true}
                          label="Enter Email Address"
                          name="txtemail"
                          onChange={(e) => {
                            dispatch(UserAction(e.target.value));
                            handleChange(e);
                          }}
                          onBlur={(e) => {
                            handleBlur(e);
                          }}
                          value={values.txtemail}
                          variant="outlined"
                        />
                        <div className="error">
                          {errors.txtemail && touched.txtemail && (
                            <Jump>{errors.txtemail}</Jump>
                          )}
                        </div>
                      </div>
                      <div className="row mb-3">
                        <TextField
                          error={
                            errors.txtpassword && touched.txtpassword && true
                          }
                          label="Enter Password"
                          type="password"
                          name="txtpassword"
                          onChange={handleChange}
                          onBlur={handleBlur}
                          value={values.txtpassword}
                          variant="outlined"
                        />
                        <div className="error">
                          {errors.txtpassword && touched.txtpassword && (
                            <Jump>{errors.txtpassword}</Jump>
                          )}
                        </div>
                      </div>
                      <div className="row mb-3">
                        <LocalizationProvider dateAdapter={DateAdapter}>
                          <DesktopDatePicker
                            label="Enter DOB"
                            name="txtdate"
                            inputFormat="DD/MM/YYYY"
                            value={values.txtdate}
                            onChange={(e) => {
                              setFieldValue("txtdate", new Date(e._d));
                              setFieldTouched("txtdate");
                            }}
                            renderInput={(params) => (
                              <TextField
                                {...params}
                                error={
                                  errors.txtdate && touched.txtdate && true
                                }
                              />
                            )}
                          />
                        </LocalizationProvider>

                        <div className="error">
                          {errors.txtdate && touched.txtdate && errors.txtdate}
                        </div>
                      </div>
                      <div className="row mb-3">
                        <MuiPhoneNumber
                          label="Mobile Number"
                          name="txtmobile"
                          error={errors.txtmobile && touched.txtmobile && true}
                          defaultCountry="in"
                          value={values.txtmobile}
                          onChange={(e) => {
                            setFieldValue("txtmobile", e);
                            setFieldTouched("txtmobile");
                            dispatch(UserMobileAction(e));
                          }}
                          onBlur={(e) => {
                            setFieldTouched("txtmobile");
                          }}
                          variant="outlined"
                        ></MuiPhoneNumber>

                        <div className="error">
                          {errors.txtmobile && touched.txtmobile && (
                            <Jump>{errors.txtmobile}</Jump>
                          )}
                        </div>
                      </div>
                      <div className="row mb-3">
                        <FormControl>
                          <FormLabel id="demo-radio-buttons-group-label">
                            Gender
                          </FormLabel>
                          <RadioGroup
                            row
                            aria-labelledby="demo-radio-buttons-group-label"
                            defaultValue="male"
                            name="radio-buttons-group"
                          >
                            <FormControlLabel
                              value="male"
                              control={<Radio />}
                              label="Male"
                            />
                            <FormControlLabel
                              value="female"
                              control={<Radio />}
                              label="Female"
                            />
                            <FormControlLabel
                              value="other"
                              control={<Radio />}
                              label="Other"
                            />
                          </RadioGroup>
                        </FormControl>
                      </div>
                      <div className="row mb-3">
                        <FormControl fullWidth>
                          <InputLabel id="demo-simple-select-label">
                            Role
                          </InputLabel>
                          <Select
                            error={errors.txtrole && touched.txtrole && true}
                            labelId="demo-simple-select-label"
                            id="demo-simple-select"
                            label="Role"
                            value={values.txtrole}
                            name="txtrole"
                            onChange={handleChange}
                            onBlur={handleBlur}
                          >
                            <MenuItem value="Doctor">Doctor</MenuItem>
                            <MenuItem value="Patient">Patient</MenuItem>
                          </Select>
                        </FormControl>
                        <div className="error">
                          {errors.txtrole && touched.txtrole && (
                            <Jump>{errors.txtrole}</Jump>
                          )}
                        </div>
                      </div>
                      <div className="row mb-3">
                        <TextField
                          label="Enter Website [Optional]"
                          variant="outlined"
                          name="txtwebite"
                          value={values.txtwebite}
                          onChange={handleChange}
                          onBlur={handleBlur}
                        />
                      </div>
                      <div className="row mb-3">
                        <input
                          type="text"
                          placeholder="Profile Photo"
                          ref={text}
                          onClick={() => {
                            text.current.type = "file";
                          }}
                          onBlur={(e) => {
                            if (!e.target.files[0]) {
                              setimgErrorMsg("Please Upload Image!!!");
                              setimgError(true);
                            } else {
                              const imgType = e.target.files[0].type.split("/");
                              const imgTypes = ["jpeg", "jpg", "png"];
                              const check = imgTypes.filter((e) => {
                                return e === imgType[1];
                              });
                              if (check.length === 0) {
                                setimgErrorMsg(
                                  "The Image Must Be Jpeg or jpg or png"
                                );
                                setimgError(true);
                              } else if (
                                e.target.files[0].size < 1000 ||
                                e.target.files[0].size > 1000000
                              ) {
                                setimgErrorMsg(
                                  "File Size Must be Between 100KB To 1 MB!!!"
                                );
                                setimgError(true);
                              } else {
                                setimgError(false);
                                getBase64(e.target.files[0]).then((base64) => {
                                  setFieldValue("txtprofile", base64);
                                });
                              }
                            }
                          }}
                          className={`form-control ${
                            imgError && "error-border"
                          }`}
                        ></input>
                        <div className="error">
                          {imgError && <Jump>{imgErrorMsg}</Jump>}
                        </div>
                      </div>
                      <div className="row mb-3">
                        <img src="" className="img-fluid" ref={imgName}></img>
                      </div>
                      <div className="row mb-3">
                        <FormControl fullWidth>
                          <InputLabel id="demo-simple-select-label">
                            Country
                          </InputLabel>
                          <Select
                            error={
                              errors.txtcountry && touched.txtcountry && true
                            }
                            labelId="demo-simple-select-label"
                            id="demo-simple-select"
                            label="Country"
                            value={values.txtcountry}
                            name="txtcountry"
                            onChange={(e) => {
                              getState(e);
                              handleChange(e);
                            }}
                            onBlur={handleBlur}
                          >
                            {country.map((item) => {
                              return (
                                <MenuItem key={item.id} value={item.id}>
                                  {item.name}
                                </MenuItem>
                              );
                            })}
                          </Select>
                        </FormControl>
                        <div className="error">
                          {errors.txtcountry && touched.txtcountry && (
                            <Jump>{errors.txtcountry}</Jump>
                          )}
                        </div>
                      </div>
                      {showState && (
                        <div className="row mb-3">
                          <FormControl fullWidth>
                            <InputLabel id="demo-simple-select-label">
                              State
                            </InputLabel>
                            <Select
                              error={
                                errors.txtstate && touched.txtstate && true
                              }
                              labelId="demo-simple-select-label"
                              id="demo-simple-select"
                              label="state"
                              value={values.txtstate}
                              name="txtstate"
                              onChange={(e) => {
                                getCity(e);
                                handleChange(e);
                              }}
                              onBlur={handleBlur}
                            >
                              {state.map((item) => {
                                return (
                                  <MenuItem key={item.id} value={item.id}>
                                    {item.name}
                                  </MenuItem>
                                );
                              })}
                            </Select>
                          </FormControl>
                          <div className="error">
                            {errors.txtstate && touched.txtstate && (
                              <Jump>{errors.txtstate}</Jump>
                            )}
                          </div>
                        </div>
                      )}
                      {showCity && (
                        <div className="row mb-3">
                          <FormControl fullWidth>
                            <InputLabel id="demo-simple-select-label">
                              City
                            </InputLabel>
                            <Select
                              error={errors.txtcity && touched.txtcity && true}
                              labelId="demo-simple-select-label"
                              id="demo-simple-select"
                              label="city"
                              value={values.txtcity}
                              name="txtcity"
                              onChange={(e) => {
                                handleChange(e);
                              }}
                              onBlur={handleBlur}
                            >
                              {city.map((item) => {
                                return (
                                  <MenuItem key={item.id} value={item.id}>
                                    {item.name}
                                  </MenuItem>
                                );
                              })}
                            </Select>
                          </FormControl>
                          <div className="error">
                            {errors.txtcity && touched.txtcity && (
                              <Jump>{errors.txtcity}</Jump>
                            )}
                          </div>
                        </div>
                      )}
                      <div className="row mb-3">
                        <TextField
                          error={
                            errors.txtzipcode && touched.txtzipcode && true
                          }
                          label="Enter Zipcode"
                          name="txtzipcode"
                          onChange={handleChange}
                          onBlur={handleBlur}
                          value={values.txtzipcode}
                          variant="outlined"
                        />
                        <div className="error">
                          {errors.txtzipcode && touched.txtzipcode && (
                            <Jump>{errors.txtzipcode}</Jump>
                          )}
                        </div>
                      </div>
                      <div className="row mb-5">
                        <TextField
                          error={
                            errors.txtaddress && touched.txtaddress && true
                          }
                          label="Enter Address"
                          multiline
                          rows={5}
                          name="txtaddress"
                          onChange={handleChange}
                          onBlur={handleBlur}
                          value={values.txtaddress}
                          variant="outlined"
                        />
                        <div className="error">
                          {errors.txtaddress && touched.txtaddress && (
                            <Jump>{errors.txtaddress}</Jump>
                          )}
                        </div>
                      </div>
                      <div className="row text-center">
                        <Button
                          type="submit"
                          disabled={isSubmitting}
                          onClick={() => {
                            if (values.txtprofile === "") {
                              setimgError(true);
                            }
                          }}
                          variant="contained"
                          color="success"
                        >
                          Submit
                        </Button>
                      </div>
                    </div>
                  </form>
                )}
              </Formik>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RegistrationForm;
