import React from "react";
import Bounce from "react-reveal/Bounce";
const Slider = () => {
  return (
    <div
      id="carouselExampleControls"
      className="carousel slide"
      data-bs-ride="carousel"
    >
      <div className="carousel-inner">
        <div className="carousel-item active">
          <img src="img/slider1.jpg" className="img-fluid" alt="..." />
          <div className="carousel-text">
            <Bounce top cascade>
              <div>Welcome To</div>
              <div> UserApp</div>
              
            </Bounce>
            <a className="btn btn-dark" href="#reg_form">
                Click Here For Registration
              </a>
          </div>
        </div>
        <div className="carousel-item">
          <img src="img/slider2.jpg" className="img-fluid" alt="..." />
          <div className="carousel-text">
          <Bounce top cascade>
              <div>Welcome To</div>
              <div> UserApp</div>
            </Bounce>
          </div>
        </div>
      </div>
      <button
        className="carousel-control-prev"
        type="button"
        data-bs-target="#carouselExampleControls"
        data-bs-slide="prev"
      >
        <span className="carousel-control-prev-icon" aria-hidden="true"></span>
        <span className="visually-hidden">Previous</span>
      </button>
      <button
        className="carousel-control-next"
        type="button"
        data-bs-target="#carouselExampleControls"
        data-bs-slide="next"
      >
        <span className="carousel-control-next-icon" aria-hidden="true"></span>
        <span className="visually-hidden">Next</span>
      </button>
    </div>
  );
};

export default Slider;
