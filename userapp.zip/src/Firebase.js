// Import the functions you need from the SDKs you need
import firebase from "firebase/compat/app";
import "firebase/compat/firestore";
import "firebase/compat/auth";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyAI6Hy2HBJqwf4f03fIv19k3jStDOt-rHs",
  authDomain: "userapp-ba2bb.firebaseapp.com",
  projectId: "userapp-ba2bb",
  storageBucket: "userapp-ba2bb.appspot.com",
  messagingSenderId: "432148559515",
  appId: "1:432148559515:web:bbfeb66681807f421eb83e",
  measurementId: "G-KF7341GS5S"
};
// Initialize Firebase
const FireBaseApp = firebase.initializeApp(firebaseConfig);

export var db = FireBaseApp.firestore();
var Auth = firebase.auth();
export default Auth;