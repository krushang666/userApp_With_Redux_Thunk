import React from "react";
import {Routes,Route} from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import Login from "./Components/Login";
import Home from "./Components/Home";
import User from "./Components/User";
function App() {
  return (
    <div className="container-fluid">
      <Routes>
        <Route path="/" element={<User/>}></Route>
        <Route path="admin/dashboard" element={<Home></Home>}></Route>
      </Routes>
    </div>
  );
}

export default App;
