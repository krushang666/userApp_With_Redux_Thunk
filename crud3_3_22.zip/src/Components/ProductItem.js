import React from "react";
import "../UI/style.css";
const ProductItem = (props) => {
    const title=(props.title.length>30?props.title.substring(0,30)+"...":props.title);
    const deleteHandler=()=>{
      props.onDelete(props.id);
    }
  return (
    <div className="productItem text-center">
      <img
        className="custom-img"
        src={props.img}
      ></img>
      <p>{title}</p>
      <h6>&#x20B9; {props.price}</h6>
      <button className="btn btn-success" onClick={()=>{
        props.onUpdate(props.id);
      }}>Update</button> &nbsp;&nbsp;<button className="btn btn-danger" onClick={deleteHandler}>Delete</button> 
    </div>
  );
};

export default ProductItem;
