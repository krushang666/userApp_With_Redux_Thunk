import React, { useRef, useState } from "react";

const AddProduct = (props) => {
  const [userInput, setuserInput] = useState({
    id: props.id,
    title: props.title,
    price: props.price,
    img: props.img,
  });
  const img = useRef();
  const imgName = useRef();
  const submitHandler = (e) => {
    e.preventDefault();
    if (props.status === 0) {
    setuserInput((prevState)=>{
        return {
            ...prevState,
            id:Math.random()
        }
    });
    props.onSubmit(userInput);
}
    else props.onUpdate(userInput);
    img.current.value = "";
    setuserInput({
      id: "",
      title: "",
      price: "",
      img: "",
    });
  };
  const imageUpload = (e) => {
    getBase64(e.target.files[0]).then((base64) => {
      setuserInput((prevState) => {
        return {
          ...prevState,
          img: base64,
        };
      });
    });
  };
  const getBase64 = (file) => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        resolve(reader.result);
        imgName.current.src = e.target.result;
      };
      reader.onerror = (er) => reject(er);
      reader.readAsDataURL(file);
    });
  };
  return (
    <div className="container">
      <form onSubmit={submitHandler}>
        <div className="row mb-4">
          <div className="col-4 mt-1" align="right">
            Product Name
          </div>
          <div className="col-6">
            <input
              type="text"
              onChange={(e) => {
                setuserInput((prevState) => {
                  return {
                    ...prevState,
                    title: e.target.value,
                  };
                });
              }}
              value={userInput.title}
              className="form-control"
              placeholder="Enter Product Name"
            />
          </div>
        </div>
        <div className="row mb-4">
          <div className="col-4 mt-1" align="right">
            Price
          </div>
          <div className="col-6">
            <input
              type="text"
              onChange={(e) => {
                setuserInput((prevState) => {
                  return {
                    ...prevState,
                    price: e.target.value,
                  };
                });
              }}
              value={userInput.price}
              className="form-control"
              placeholder="Enter Price"
            />
          </div>
        </div>
        <div className="row mb-4">
          <div className="col-4 mt-1" align="right">
            Image
          </div>
          <div className="col-6">
            <input
              type="file"
              onChange={imageUpload}
              ref={img}
              className="form-control"
              placeholder="Enter Price"
            />
            <br />
            <img src={props.img} ref={imgName} className="img-fluid" />
          </div>
        </div>
        <div className="row mb-4">
          <div className="col-12 mt-1" align="center">
            <button type="submit" className="btn btn-success">
              {props.status===0?"Add Product":"Update Product"}
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};

export default AddProduct;
