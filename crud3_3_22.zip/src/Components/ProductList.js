import React from "react";
import ProductItem from "./ProductItem";

const ProductList=(props)=>{   
    return (
        <div className="productList">
            {
                props.data.map((item)=>{
                    let data={key:item.id,...item}
                    return <ProductItem {...data} onDelete={(id)=>{
                        props.onDelete(id)
                    }}
                    onUpdate={(id)=>{
                        props.onUpdate(id)
                    }}
                    ></ProductItem>
                })
            }
        </div>
        
    )
}

export default ProductList;