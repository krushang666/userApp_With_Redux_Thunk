
import React from "react";
const ProductSectionItem = (props) => {
    const title=(props.title.length>30?props.title.substring(0,30)+"...":props.title);
    
  return (
    <div className="ProductSectionItem text-center">
      <img
        className="custom-img"
        src={props.img}
      ></img>
      <p>{title}</p>
      <h6>&#x20B9; {props.price}</h6><br/>
      <button className="btn btn-dark">View</button>
     </div>
  );
};

export default ProductSectionItem;
