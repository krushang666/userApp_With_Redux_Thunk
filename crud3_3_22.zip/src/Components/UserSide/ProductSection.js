import axios from "axios";
import React, { useEffect, useState } from "react";
import $ from "jquery"
import OwlCarousel from "react-owl-carousel";
import "owl.carousel/dist/assets/owl.carousel.css";
import "owl.carousel/dist/assets/owl.theme.default.css";
import ProductSectionItem from "./ProductSectionItem";
const ProductSection = () => {
  const [data, setdata] = useState([]);
  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    const res = await axios.get("http://localhost:3300/products");
    setdata(res.data);
  };
  console.log(data);
  return (
    <div className="HomePage_ProductSection">
      <div className="section_title">Our Products</div>
      <div className="section_body">
        <OwlCarousel className="owl-theme InfiniteProdcutList" loop nav>
          {data.map((item) => {
            return <ProductSectionItem {...item}></ProductSectionItem>;
          })}
        </OwlCarousel>
      </div>
    </div>
  );
};

export default ProductSection;
