import React from "react";
const AboutSection = () => {
  return (
    <div className="HomePage_about_section">
      <div className="section_title">About Us</div>
      <div className="section_body">
        <div className="productList mt-5">
          <div className="card productItem text-center">
            <h2 className="card-title">Who Are We?</h2>
            <p className="card-description">
              Lorem Ipsum is simply dummy text of the printing and typesetting
              industry. Lorem Ipsum has been the industry's standard dummy text
              ever since the 1500s,
            </p>
          </div>
          <div className="card productItem text-center">
            <h2 className="card-title">What We Offer</h2>
            <p className="card-description">
              Lorem Ipsum is simply dummy text of the printing and typesetting
              industry. Lorem Ipsum has been the industry's standard dummy text
              ever since the 1500s,
            </p>
          </div>
          <div className="card productItem text-center">
            <h2 className="card-title">Why Choose Us?</h2>
            <p className="card-description">
              Lorem Ipsum is simply dummy text of the printing and typesetting
              industry. Lorem Ipsum has been the industry's standard dummy text
              ever since the 1500s,
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AboutSection;
