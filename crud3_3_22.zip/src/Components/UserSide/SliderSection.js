import React from "react";
const SliderSection = () => {
  return (
    <div className="HomePage_slider">
      <div className="HomePage_slider_text text-center">
        <h1>Welcome To ,<br/>Online Shopping</h1><br/>
        <button className="btn btn-dark"> 
            Explore Now
        </button>
      </div>
    </div>
  );
};

export default SliderSection;
