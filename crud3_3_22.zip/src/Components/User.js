import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import Login from "./Login";
import UserHome from "./UserHome";

const User = () => {
  const user = useSelector((state) => state.user);
  
  return <>{!user.status ? <Login></Login> : <UserHome />}</>;
};

export default User;
