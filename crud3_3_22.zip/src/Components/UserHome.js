import React from "react";
import "../UI/style.css";
import AboutSection from "./UserSide/AboutSection";
import NavBar from "./UserSide/NavBar";
import ProductSection from "./UserSide/ProductSection";
import SliderSection from "./UserSide/SliderSection";
import Section from "./UserSide/SliderSection";
const UserHome = () => {
  return (
    <div className="user_home">
      <NavBar/>
      <SliderSection/>
      <AboutSection/>
      <ProductSection></ProductSection>
    </div>
  );
};

export default UserHome;
