import React, { useEffect, useRef, useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import Card from "../UI/Card"
import axios from "axios";
import ProductList from "./ProductList";
import "../UI/style.css";
import $ from "jquery";
import AddProduct from "./AddProduct";
const Home=()=>{
const [data, setdata] = useState([]);
const [status, setstatus] = useState(0)
const [showForm, setshowForm] = useState(false)
const viewPanel = useRef();
const addPanel = useRef();
const [userInput, setuserInput] = useState({
  id:"",
  title: "",
  price: "",
  img: ""
});
useEffect(() => {
  fetchData();
  $(addPanel.current).hide();
}, []);

const fetchData = async () => {
  const res = await axios.get("http://localhost:3300/products");
  setdata(res.data);
};
const handlePanel = () => {
  $(viewPanel.current).slideUp("slow", () => {
    setshowForm(true)
    $(addPanel.current).slideDown("slow");
  });
};

const submitHandler = (finalData) => {
  
  axios.post("http://localhost:3300/products",{
    ...finalData
  }).then((success)=>{
    fetchData();
  });
  $(addPanel.current).slideUp("slow", () => {
    $(viewPanel.current).slideDown("slow");
  });
};

const deleteHandler=(id)=>{
  axios.delete("http://localhost:3300/products/"+id).then(()=>{
    alert("Deleted Data SuccessFully!!!");
    fetchData();
  })
}

const updateHandler= async (id)=>{
  const res = await axios.get("http://localhost:3300/products/"+id);
  setuserInput({...res.data});
  setstatus(1);
  setshowForm(true)
  $(viewPanel.current).slideUp("slow", () => {
    $(addPanel.current).slideDown("slow");
  });
}

const updateDataHandler=(data)=>{
  console.log(data);
  axios.put("http://localhost:3300/products/"+data.id,{
    ...data
  }).then(()=>{
    alert("Update SuccessFully!!!");
    fetchData();
    setstatus(0);
    setshowForm(false);
    setuserInput({
      id:"",
      title: "",
      price: "",
      img: ""
    })
  })
  $(addPanel.current).slideUp("slow", () => {
    $(viewPanel.current).slideDown("slow");
  });
}
  return (
    <Card
      color="border-primary"
      header={
        <div className="row">
          <div className="col-6">Products</div>
          <div className="col-6" align="right">
            <button className="btn btn-success" onClick={handlePanel}>
              Add New Item
            </button>
          </div>
        </div>
      }
      headerColor="bg-transparent border-0"
    >
      <div ref={addPanel}>
        <Card
          color="border-dark"
          header="Add Product"
          headerColor="bg-dark text-white"
        >
          { showForm && <AddProduct onSubmit={submitHandler} onUpdate={updateDataHandler} {...userInput} status={status} />}
        </Card>
      </div>

      <div ref={viewPanel}>
        <Card
          color="border-dark"
          header="Product List"
          headerColor="bg-dark text-white"
        >
          <ProductList data={data} onDelete={deleteHandler} onUpdate={updateHandler}></ProductList>
        </Card>
      </div>
    </Card>
  )
}

export default Home;