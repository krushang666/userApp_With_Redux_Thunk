import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { LoginAction } from "../Storage/LoginAction";
import Card from "../UI/Card";
import "../UI/style.css";

const Login = () => {
  const dispatch = useDispatch();
  const [userInput, setuserInput] = useState({
    username: "",
    password: "",
  });
 
  const loginHandler = async (e) => {
      e.preventDefault();
    if (userInput.username === "user" && userInput.password === "user123") {
      const check = await dispatch(LoginAction(userInput.username));
    } else {
      alert("Invalid Username or Password");
    }
  };
  return (
    <div className="Login_Form">
      <Card
        header="Login"
        headerColor="bg-dark text-white"
        color="border-dark login-card"
      >
        <form method="post" onSubmit={loginHandler}>
          <div className="text-center">
            <img src="img/user.png" className="custom-img" />
            <div className="row">
              <div className="col-12">
                <input
                  type="text"
                  required
                  className="form-control"
                  onChange={(e) => {
                    setuserInput((prevState) => {
                      return {
                        ...prevState,
                        username: e.target.value,
                      };
                    });
                  }}
                  placeholder="Enter Username"
                ></input>
              </div>
            </div>
            <br />
            <div className="row">
              <div className="col-12">
                <input
                  type="text"
                  required
                  onChange={(e) => {
                    setuserInput((prevState) => {
                      return {
                        ...prevState,
                        password: e.target.value,
                      };
                    });
                  }}
                  className="form-control"
                  placeholder="Enter Password"
                ></input>
              </div>
            </div>
            <br />
            <div className="row">
              <div className="col-12">
                <button className="btn btn-success">Login</button>
              </div>
            </div>
          </div>
        </form>
      </Card>
    </div>
  );
};

export default Login;
