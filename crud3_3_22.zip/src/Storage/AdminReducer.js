const initialValue = {
    status: false,
    username: null,
};
const AdminReducer = (state = initialValue, action) => {
  switch (action.type) {
    case "LoggedIN":
        return {
            status: true,
            username: action.username,
          };
    default:
      return {
        status: false,
        username: null,
      };
  }
};

export default AdminReducer;
