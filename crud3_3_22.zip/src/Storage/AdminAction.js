export const AdminLoginAction=(username)=>{
    return {
        type:'LoggedIN',
        username:username
    }
}

export const AdminLogoutAction=()=>{
return {
    type:"LoggedOut"
}
}