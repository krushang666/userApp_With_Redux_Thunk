export const LoginAction=(username)=>{
        localStorage.setItem("username",username);
        return {
            type:'LoggedIN',
            username:username
        }
}

export const LogoutAction=()=>{
    return {
        type:"LoggedOut"
    }
}