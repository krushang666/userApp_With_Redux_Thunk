import React from "react";
const Card = (props) => {

  const Header = () => {
    return props.header;
  };
  return (
    <div className={`card m-3 ${props.color}`}>
      {props.header && (
        <div className={`card-header ${props.headerColor} `}>
          <h3><Header /></h3>
        </div>
      )}
      <div className="card-body p-5">{props.children}</div>
      {props.footer && (
        <div className={`card-footer ${props.footerColor} `}>
          {props.footer}
        </div>
      )}
    </div>
  );
};

export default Card;
