import React, { useEffect, useState } from "react";
import { useDispatch,useSelector } from "react-redux";

function App() {
  const [users, setusers] = useState([]);
  const userReducer=useSelector(state=>state.users)
  const loading=useSelector(state=>state.loading)
  const dispatch=useDispatch()
  useEffect(() => {
    dispatch({type:"GET_USERS_REQUEST"});
  }, []);
  useEffect(()=>{
    setusers(userReducer)
  },[userReducer])
  return (
    <div>
      <h1>Welcome to React Redux Saga</h1>
      {loading && <h2>Loading...</h2>}
      {users && users.map((user,  i) => <h1 key={i}>{user.name}</h1>)}
    </div>
  );
}

export default App;
