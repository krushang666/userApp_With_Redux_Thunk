import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import createSagaMiddleware from "redux-saga";
import { createStore, applyMiddleware,compose } from 'redux'
import { Provider } from 'react-redux';
import Saga from './Actions';
import Users from './Users';
import { apply } from 'redux-saga/effects';


const mySaga=createSagaMiddleware()
const store=createStore(Users,compose(
  applyMiddleware(mySaga),
  window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__()))

  mySaga.run(Saga)
ReactDOM.render(
    <Provider store={store}>
    <App />
    </Provider>
    ,
  document.getElementById('root')
);