import { call, put,takeLatest } from "redux-saga/effects";

function* fetchUsers() {
  try {
    const user = yield call(async () => {
     const data=await fetch("https://jsonplaceholder.typicode.com/users", {
        method: "GET",
      });
      return data.json().then(success=>{return success});
    });
    console.log(user);
    yield put({ type: "GET_USERS_SUCCESS", users: user });
  } catch (e) {
    yield put({ type: "GET_USERS_FAILURE", error: e });
  }
}

export default function* Saga() {
  yield takeLatest("GET_USERS_REQUEST", fetchUsers);
}
